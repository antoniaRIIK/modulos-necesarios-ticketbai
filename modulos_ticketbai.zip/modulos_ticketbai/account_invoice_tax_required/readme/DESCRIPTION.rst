This module adds functional a check on invoice
to force user to set tax on invoice line.
